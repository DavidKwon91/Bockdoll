Utils to be used

list

- BockdollEndoing\
  Categorical Encoding based on target

- Startified Group K Fold\
  Group K Fold, with stratified startegy\
  Reference link : [links](https://www.kaggle.com/jakubwasikowski/stratified-group-k-fold-cross-validation)
